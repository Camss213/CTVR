ALTER TABLE accidents
    RENAME COLUMN current_weather TO weather;