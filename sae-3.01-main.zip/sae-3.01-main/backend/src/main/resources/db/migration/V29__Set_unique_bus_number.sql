ALTER TABLE bus
    ADD CONSTRAINT uc_bus_number UNIQUE (number);