ALTER TABLE pass
    ADD CONSTRAINT uc_b6819786aaef25446a9f86827 UNIQUE (line_number, position);