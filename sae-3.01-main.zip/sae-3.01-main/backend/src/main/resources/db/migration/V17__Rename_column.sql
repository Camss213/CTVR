ALTER TABLE bus
    RENAME COLUMN implementation TO implementation_date;