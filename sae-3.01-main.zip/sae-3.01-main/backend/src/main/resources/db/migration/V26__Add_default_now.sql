ALTER TABLE accidents
    ALTER COLUMN file_opening_date SET DEFAULT NOW();