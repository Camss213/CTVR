ALTER TABLE drivers
    RENAME COLUMN post_code TO postal_code;