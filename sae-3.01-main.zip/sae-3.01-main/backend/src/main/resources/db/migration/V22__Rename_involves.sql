ALTER TABLE involve
    RENAME TO involves;

ALTER INDEX ix_pk_involve RENAME TO ix_pk_involves;