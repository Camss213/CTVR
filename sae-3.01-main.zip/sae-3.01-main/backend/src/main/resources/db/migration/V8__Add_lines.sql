CREATE TABLE lines
(
    line_number INTEGER NOT NULL,
    CONSTRAINT pk_lines PRIMARY KEY (line_number)
);