ALTER TABLE pass
    RENAME COLUMN "order" TO position;