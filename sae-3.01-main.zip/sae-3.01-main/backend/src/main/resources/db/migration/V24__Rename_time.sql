ALTER TABLE accidents
    RENAME COLUMN hour TO time;