package fr.iut.valence.but.info.ctvr.backend.model;

public enum Weather {
    SNOW,
    RAIN,
    FOG,
    SUN
}
