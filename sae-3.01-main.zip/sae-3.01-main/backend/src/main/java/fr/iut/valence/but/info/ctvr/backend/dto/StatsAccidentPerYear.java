package fr.iut.valence.but.info.ctvr.backend.dto;

public record StatsAccidentPerYear(Integer year, Long nbAccident) {
}
