package fr.iut.valence.but.info.ctvr.backend.model;

public record NeedId(Integer interventionId, String workforceCode) {
}
