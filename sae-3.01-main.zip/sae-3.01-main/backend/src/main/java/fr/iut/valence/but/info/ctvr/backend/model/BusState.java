package fr.iut.valence.but.info.ctvr.backend.model;

public enum BusState {
    IN_SERVICE, UNDER_REPAIR
}
