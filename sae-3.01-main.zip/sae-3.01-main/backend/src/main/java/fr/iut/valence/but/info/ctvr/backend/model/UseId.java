package fr.iut.valence.but.info.ctvr.backend.model;

public record UseId(Integer interventionId, String supplyCode) {
}
