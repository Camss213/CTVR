package fr.iut.valence.but.info.ctvr.backend.model;

public record PassId(Integer lineNumber, String stopName) {
}
