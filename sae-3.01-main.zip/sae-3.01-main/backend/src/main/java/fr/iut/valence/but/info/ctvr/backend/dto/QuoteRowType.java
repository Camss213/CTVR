package fr.iut.valence.but.info.ctvr.backend.dto;

public enum QuoteRowType {
    WORKFORCE, SUPPLY
}
