package fr.iut.valence.but.info.ctvr.backend.dto;

public record LineSummary( Integer number, String color, String firstStopName, String lastStopName) {

}
