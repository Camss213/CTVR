package fr.iut.valence.but.info.ctvr.backend.model;

public record InvolveId(
        Integer thirdPartyId,
        Integer accidentYear,
        Integer accidentNoSeq
) {
}
