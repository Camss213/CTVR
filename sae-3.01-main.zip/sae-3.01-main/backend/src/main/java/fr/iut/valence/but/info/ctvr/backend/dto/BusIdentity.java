package fr.iut.valence.but.info.ctvr.backend.dto;

public record BusIdentity(Byte number, String registration) {
}
