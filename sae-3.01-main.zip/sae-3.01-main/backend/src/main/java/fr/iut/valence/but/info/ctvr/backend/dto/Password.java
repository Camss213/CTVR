package fr.iut.valence.but.info.ctvr.backend.dto;

public record Password(String password, String oldPassword) {
}
