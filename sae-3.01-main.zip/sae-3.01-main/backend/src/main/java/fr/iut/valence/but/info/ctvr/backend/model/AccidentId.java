package fr.iut.valence.but.info.ctvr.backend.model;

public record AccidentId(Integer year, Integer noSeq) {
}
