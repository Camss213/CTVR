package fr.iut.valence.but.info.ctvr.backend.dto;

public record Username(String username) {
}
