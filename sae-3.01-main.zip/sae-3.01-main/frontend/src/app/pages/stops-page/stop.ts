export interface Stop {
    name: string;
}
