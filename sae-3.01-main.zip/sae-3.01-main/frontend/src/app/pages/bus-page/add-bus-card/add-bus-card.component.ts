import { Component } from '@angular/core';

@Component({
    selector: 'app-add-bus-card',
    imports: [],
    templateUrl: './add-bus-card.component.html',
    styleUrl: './add-bus-card.component.css',
})
export class AddBusCardComponent {}
