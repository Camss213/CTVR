import { Component } from '@angular/core';

@Component({
    selector: 'app-add-third-card',
    imports: [],
    templateUrl: './add-third-party-card.component.html',
    styleUrl: './add-third-party-card.component.css',
})
export class AddThirdCardComponent {}
