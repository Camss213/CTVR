import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../auth/auth.service';

@Component({
    selector: 'app-forbidden-page',
    imports: [RouterLink],
    templateUrl: './forbidden-page.component.html',
    styleUrl: './forbidden-page.component.css',
})
export class ForbiddenPageComponent {
    constructor(public service: AuthService) {}
}
