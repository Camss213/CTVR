import { Component } from '@angular/core';

@Component({
    selector: 'app-card-skeleton',
    imports: [],
    template: '',
    styleUrl: './card-skeleton.component.css',
})
export class CardSkeletonComponent {}
