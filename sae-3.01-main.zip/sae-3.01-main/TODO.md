## Fix

- Supprimer les codes dupliqués aussi.
- Corigé les fôte d'aurteaugrafe
- Il faudrait faire des composants pour séparer les grosses pages

## Si on a le temps

- Déplacer les arrêts dans les lignes
- Afficher les dernières réparation dans les bus
- Faire des barres de recherche (Permet de fix la superposition des boutons de compte et de déconnexion et c'est pas si dure à en faire des simples)
- Système d'impression de la page des devis et des accidents
- harmoniser les noms de fonction
